require 'rails_helper'

RSpec.describe BooksController, type: :controller do

end
