require 'rails_helper'

RSpec.describe "cart/show.html.haml", type: :view do
  pending "add some examples to (or delete) #{__FILE__}"
end
