require 'rails_helper'

RSpec.describe "category/show.html.haml", type: :view do
  pending "add some examples to (or delete) #{__FILE__}"
end
